import { Cube } from "./shapes/cube.js"
export { Cube } from "./shapes/cube.js"

import { Sphere } from "./shapes/sphere.js"
export { Sphere } from "./shapes/sphere.js"


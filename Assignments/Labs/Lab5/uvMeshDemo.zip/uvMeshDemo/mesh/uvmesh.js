class UVMesh extends Mesh
{

	// creates a textured mesh with the given arrays
	constructor(gl, program, positionArray, indexArray, normalArray, uvArray, imageID, flipTexture, position=new Vector(), rotation=new Quaternion(), scale=new Vector(1,1,1))
	{
		
	}

	activate()
	{
		
	}

	draw()
	{
		
	}
}
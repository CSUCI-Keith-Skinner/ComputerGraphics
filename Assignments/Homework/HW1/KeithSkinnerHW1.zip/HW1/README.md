# HW 1 - Transform

1. Download attached [HW1.zip][HW1.zip].
2. Complete the Vector, Quaternion, and Matrix classes (located in the "class skeletons" folder) in Labs 2 and 3.
3. Complete the Transform class.
4. Use the homework 1 test script in the test folder to ensure everything is working as intended.
  - Create an html script which includes all four class scripts and the test script.
  - Run this html (or host a server, if preferred).
5. zip the completed class scripts and html and submit the zip file.

[HW1.zip]: https://cilearn.csuci.edu/courses/8813/files/1098930/download?wrap=1
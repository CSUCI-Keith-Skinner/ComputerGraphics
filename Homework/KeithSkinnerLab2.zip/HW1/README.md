## Instructions
1. Download attached HW1.zip.
2. Complete the Vector, Quaternion, and Matrix classes (located in the "class skeletons" folder) in Labs 2 and 3.
3. Complete the Transform class.
4. Use the homework 1 test script in the test folder to ensure everything is working as intended.
5. Create an html script which includes all four class scripts and the test script.
6. Run this html (or host a server, if preferred).
7. zip the completed class scripts and html and submit the zip file.
